# Sample Vendor Risk Assessment Report

> **Fictional example.** Vendor, organization, people and results are invented to demonstrate the toolkit's output. Figures come from the sample data in `templates/Vendor_Risk_Management_Workbook.xlsx`.

| | |
|---|---|
| **Organization** | Meridian Analytics Group (fictional) |
| **Vendor** | NimbusAI Language Platform (V-002) |
| **Service** | Hosted large-language-model API embedded in the customer support assistant |
| **Category** | AI/ML Software |
| **Business owner** | Director of Customer Support |
| **Assessment date** | 10 October 2026 (initial assessment, in progress) |
| **Prepared by** | GRC Analyst |

## 1. Executive Summary

NimbusAI would process customer support conversations that include personal and confidential data. Its inherent risk is **High (76)**. Vendor controls are generally sound (82% control effectiveness), producing a **Medium residual score of 32.6**.

**Recommendation: do not approve yet.** The vendor does not commit contractually that customer prompts and outputs are excluded from model training, which is a critical control for this use case. Approval should be reconsidered once the contract is amended and the remaining AI governance gaps have a dated plan.

## 2. Inherent Risk

| Factor | Score (1–5) | Rationale |
|---|---|---|
| Data sensitivity | 5 | Support conversations contain customer personal data and confidential business information |
| Business criticality | 3 | Support assistant degrades service if unavailable, but human agents provide a fallback |
| System / network access | 3 | API integration with the ticketing system; no infrastructure access |
| Regulatory exposure | 4 | Personal data subject to GDPR and similar laws |
| Substitutability | 2 | Several comparable LLM providers exist |
| AI impact | 5 | Generative output shapes customer-facing responses |

**Inherent score: 76 (High).**

## 3. Control Effectiveness

Overall control effectiveness: **82%**. Questionnaire completion: 100%.

| Domain | Score |
|---|---|
| Governance & Risk Management | 88% |
| Identity & Access Management | 90% |
| Data Protection & Privacy | 93% |
| Cloud & Infrastructure Security | 100% |
| Application & Vulnerability Management | 88% |
| Logging, Monitoring & Incident Response | 86% |
| Business Continuity & Resilience | 88% |
| Subcontractor & Fourth-Party Management | 79% |
| Legal, Regulatory & Compliance | 88% |
| **AI Governance & Model Risk** | **48%** |

The weakest area by far is AI governance, which is where the key findings sit.

## 4. Key Findings

| # | Finding | Control | Severity | Recommended action |
|---|---|---|---|---|
| 1 | **No contractual commitment that customer data, prompts and outputs are excluded from model training.** Vendor retains prompts for 30 days and reserves the right to use them for improvement. | AIG-02 (critical) | **Critical** | Amend the DPA to include zero-retention and no-training terms before go-live |
| 2 | No defined process for AI incident reporting and customer notification (harmful outputs, model failure, data leakage) | AIG-08 | High | Require an AI incident procedure and notification commitment in the contract |
| 3 | AI governance policy, impact assessments, testing and AI-specific security controls are only partially evidenced | AIG-01, 03, 05, 07 | Medium | Request evidence; run an internal prompt-injection test before launch |
| 4 | Independent attestation is SOC 2 Type I only; Type II period ends December 2026 | GOV-02 | Medium | Obtain the Type II report and bridge letter; review at first interim check |
| 5 | Incident response and DR testing only partially evidenced; subcontractor assessment partial | IRM-01, BCR-02, 4PM-02 | Medium | Request test summaries and subprocessor assessment approach |
| 6 | No cyber liability insurance evidence | REG-03 | Low | Request certificate of insurance |

## 5. Residual Risk

```
Residual score = 76 × (1 − 0.815 × 0.70) = 32.6   →   Medium
```

| Measure | Result |
|---|---|
| Residual rating | **Medium** |
| Critical gaps | **1** |
| Recommended decision | **Remediate critical gaps before approval** |
| Required approver (residual rating) | Business Owner + Information Security Manager, plus AI governance review |

## 6. Registered Risks

| ID | Risk | Inherent | Residual (target) | Treatment |
|---|---|---|---|---|
| VR-004 | Customer prompts retained and used to train vendor models | 20 (Critical) | 10 (High) | Negotiate zero-retention and no-training clauses; block go-live until signed |
| VR-005 | Inaccurate or fabricated outputs mislead customers | 12 (High) | 9 (Medium) | Output confidence thresholds, response logging, monthly quality review |
| VR-006 | Prompt injection via integrations leads to data exfiltration | 12 (High) | 8 (Medium) | Internal red-team test; input/output filtering |

## 7. Conditions for Approval

1. Executed DPA amendment with zero-retention and no-training commitments (VR-004).
2. AI incident reporting commitment added to the contract.
3. SOC 2 Type II report received within 90 days of go-live.
4. Internal prompt-injection test completed with no critical findings.
5. Human review of high-impact responses in place at launch.

## 8. Monitoring Plan

As a High inherent-risk vendor: full reassessment every 18 months, interim check every 6 months, monthly security posture monitoring, quarterly SLA review, and review of each major model release.

## 9. Sign-off

| Role | Name | Decision | Date |
|---|---|---|---|
| GRC Analyst | | Recommendation issued | |
| Information Security Manager | | | |
| Privacy Officer | | | |
| AI Governance Lead | | | |
| Business Owner | | | |
