# Third-Party Risk Management: Program Overview & Policy

**Version:** 1.0 | **Owner:** GRC / Information Security | **Review cycle:** Annual
**Example organization:** Meridian Analytics Group (fictional)

## 1. Purpose

This policy sets out how the organization identifies, assesses, approves and monitors third parties that process its data, connect to its systems, or support critical services. It places particular emphasis on **cloud service providers** and **AI software vendors**, where data exposure, concentration risk and model behavior create risks that traditional supplier reviews miss.

## 2. Scope

The policy applies to every third party that:

- stores, processes or transmits organizational or customer data;
- has logical or physical access to organizational systems or facilities;
- provides cloud infrastructure, SaaS applications, managed services or AI/ML functionality; or
- supports a business process whose failure would materially affect operations.

Out of scope: vendors that provide only non-sensitive goods and have no data or system access (e.g., office supplies), subject to Procurement's standard checks.

## 3. Policy Statements

1. No vendor may receive organizational data or access to systems until the approval workflow is complete (see [03-approval-workflow.md](03-approval-workflow.md)).
2. Every vendor is recorded in the Vendor Register with an owner, a risk tier and a next review date.
3. Assessment depth is proportionate to inherent risk. Higher tiers require more evidence, more senior approval and more frequent monitoring.
4. Critical control gaps must be remediated or formally risk-accepted before go-live.
5. AI vendors undergo an additional AI governance review covering data use, model documentation, testing, and regulatory classification.
6. Contracts for in-scope vendors include a security schedule covering breach notification, audit rights, subcontractor flow-down, and data return or deletion.
7. Vendors are monitored throughout the relationship and reassessed on schedule and on trigger events (see [04-monitoring-schedule.md](04-monitoring-schedule.md)).
8. Exits are planned: High and Critical vendors require a documented exit strategy.

## 4. Roles and Responsibilities

| Role | Responsibilities |
|---|---|
| **Business Owner** | Sponsors the vendor; provides the business case and data-flow description; owns the relationship, SLA reviews and exit planning |
| **GRC Analyst** | Maintains the Vendor Register; triages inherent risk; issues and scores questionnaires; maintains the Risk Register; tracks monitoring |
| **Security Analyst / Architect** | Validates vendor evidence; reviews architecture and integrations; performs posture checks; recommends remediation |
| **Privacy Officer** | Reviews DPAs, transfers and subprocessors; performs DPIAs |
| **Legal / Procurement** | Negotiates contract terms and the security schedule; screens vendors; manages renewals |
| **AI Governance Lead** | Reviews AI use cases, impact assessments, model documentation and regulatory classification |
| **Approver (by residual rating)** | Makes the approve, conditionally approve or reject decision; owns any risk acceptance |
| **CISO** | Owns the program; approves Critical-tier vendors with the Risk Committee; reports on program metrics |

## 5. Lifecycle Summary

| Stage | Description | Tool in this toolkit |
|---|---|---|
| 1. Request and business case | Intake and duplicate check | `Vendor_Register` |
| 2. Inherent risk triage | Score six factors and assign a tier | `Vendor_Register`, `Methodology` |
| 3. Due diligence | Questionnaire and evidence collection | `Questionnaire`, `Due_Diligence` |
| 4. Security review | Validate evidence; score control effectiveness | `Assessment_Results` |
| 5. Privacy and legal review | DPA, transfers, contract schedule | `Due_Diligence` |
| 6. AI governance review | AI vendors only | `Due_Diligence` (AI section) |
| 7. Residual risk and recommendation | Calculate residual risk; log risks | `Vendor_Register`, `Risk_Register` |
| 8. Approval decision | Per authority matrix | `Approval_Workflow` |
| 9. Contracting and onboarding | Execute contract; configure access and logging | `Due_Diligence` |
| 10. Monitoring and offboarding | Scheduled reviews; exit | `Monitoring` |

## 6. Exceptions

Exceptions to this policy must be documented, approved by the CISO, time-bound (maximum 12 months), and recorded in the Risk Register with status "Accepted".

## 7. Metrics Reported to Management

- Number of vendors by inherent and residual rating
- Average control effectiveness
- Vendors with open critical control gaps
- Overdue reassessments and expired attestations
- Open High and Critical vendor risks and their target dates

These are produced by the `Dashboard` sheet.

## 8. Related Standards

ISO/IEC 27001:2022 (A.5.19 to A.5.23), ISO/IEC 42001:2023 (Annex A.10), NIST CSF 2.0 (GV.SC), NIST AI RMF 1.0.
