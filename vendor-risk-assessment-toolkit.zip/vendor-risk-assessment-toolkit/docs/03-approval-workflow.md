# Security Review & Approval Workflow

## 1. Workflow Overview

```mermaid
flowchart TD
    A[1. Request & business case] --> B[2. Inherent risk triage]
    B --> C[3. Due diligence & questionnaire]
    C --> D[4. Security review]
    D --> E[5. Privacy & legal review]
    E --> F{AI vendor?}
    F -- Yes --> G[6. AI governance review]
    F -- No --> H[7. Residual risk & recommendation]
    G --> H
    H --> I{Critical gaps open?}
    I -- Yes --> J[Remediate or formally accept]
    J --> H
    I -- No --> K[8. Approval decision]
    K -- Approve / Conditional --> L[9. Contracting & onboarding]
    K -- Reject --> M[Record rationale; close request]
    L --> N[10. Monitoring & offboarding]
    N -- Trigger event or scheduled review --> C
```

## 2. Stages, Owners and SLAs

SLAs are in business days and exclude time spent waiting for the vendor.

| # | Stage | Owner | Key outputs | SLA | Decision gate |
|---|---|---|---|---|---|
| 1 | Request and business case | Business Owner / GRC | Vendor Register entry | 2 | Intake complete; no duplicate vendor |
| 2 | Inherent risk triage | GRC Analyst | Inherent score, rating, assessment scope | 2 | Tier assigned |
| 3 | Due diligence and questionnaire | GRC / Procurement | Completed questionnaire; evidence pack | 10 | Evidence complete |
| 4 | Security review | Security Analyst / Architect | Assessment results; findings list | 5 | Critical gaps identified |
| 5 | Privacy and legal review | Privacy Officer / Legal | Contract mark-up; DPIA where required | 5 | DPA executed or exception approved |
| 6 | AI governance review (AI vendors) | AI Governance Lead | AI governance sign-off | 5 | AI use case approved |
| 7 | Residual risk and recommendation | GRC Analyst | Residual rating; Risk Register entries | 3 | Recommendation issued |
| 8 | Approval decision | Approver | Signed decision record | 5 | Decision recorded |
| 9 | Contracting and onboarding | Procurement / IT / Business Owner | Go-live checklist; monitoring entry | 10 | Checklist signed |
| 10 | Monitoring and offboarding | GRC / Business Owner | Review records; exit certificate | Per schedule | Review complete; exit verified |

## 3. Approval Authority Matrix

Approval authority depends on the **residual** rating.

| Residual rating | Required approver | Conditions | Maximum validity |
|---|---|---|---|
| Low | Business Owner + GRC Analyst | Standard terms; no open critical gaps | Until next scheduled review |
| Medium | Business Owner + Information Security Manager | Open findings tracked with owners and dates | Until next scheduled review |
| High | Information Security Manager + Privacy/Legal + Head of Business Unit | Conditional approval; dated remediation plan; exit plan on file | 12 months or until milestones missed |
| Critical | CISO + Risk Committee | Formal risk acceptance memo; enhanced monitoring; tested exit plan | 12 months; quarterly reporting |

## 4. Decision Outcomes

- **Approve:** the vendor may be onboarded on standard terms.
- **Conditionally approve:** onboarding may proceed, subject to a remediation plan with dated milestones. Missed milestones trigger escalation to the approver.
- **Reject:** the vendor may not receive data or access. The rationale is recorded, and the request may be resubmitted only when the blocking issue is resolved.

## 5. Exception and Escalation Rules

1. A critical control gap must be remediated before go-live or formally risk-accepted by the approver for the Critical tier.
2. AI vendors require the AI governance review (stage 6) in addition to the standard approver, regardless of residual rating.
3. Risk acceptances are time-bound (maximum 12 months), recorded in the Risk Register, and re-approved at expiry.
4. Business units must not sign contracts or share data with a vendor before stage 8 is complete. Emergency requests need written CISO approval.
5. Any SLA breach in the workflow is escalated to the GRC lead.

## 6. Decision Record Template

| Field | Entry |
|---|---|
| Vendor ID / name | |
| Service and data types | |
| Inherent rating / score | |
| Control effectiveness | |
| Residual rating / score | |
| Critical gaps (list) | |
| Open risks (Risk IDs) | |
| Recommendation | |
| Decision | Approve / Conditionally approve / Reject |
| Conditions and milestones | |
| Approver name, role, date | |
| Next review date | |
