# Risk Scoring Methodology

This document explains how the workbook calculates inherent risk, control effectiveness and residual risk. All parameters are editable on the `Methodology` sheet. Values shown are illustrative defaults to be calibrated to the organization's risk appetite.

## 1. Inherent Risk

Inherent risk is the risk a vendor poses **before** considering its controls. Each vendor is scored 1 to 5 on six factors:

| Factor | Weight | What it measures |
|---|---|---|
| Data sensitivity | 30% | Type and volume of data shared, from public to special-category or payment data |
| Business criticality | 25% | Impact on operations if the service fails |
| System / network access | 15% | Level of access to internal systems and networks |
| Regulatory exposure | 10% | Regulated data or activity (GDPR, HIPAA, PCI DSS, SOX) |
| Substitutability | 10% | Difficulty of replacing the vendor (lock-in) |
| AI impact | 10% | Degree to which AI shapes decisions or processes sensitive data (1 = no AI) |

```
Inherent score = Σ(score × weight) ÷ Σ(weights) × 20      → range 20 to 100
```

### Rating bands

| Rating | Inherent score ≥ | Residual score ≥ | Full reassessment | Interim check |
|---|---|---|---|---|
| Low | 0 | 0 | 36 months | At renewal |
| Medium | 40 | 25 | 24 months | 12 months |
| High | 60 | 40 | 18 months | 6 months |
| Critical | 80 | 60 | 12 months | 3 months |

Residual thresholds are lower than inherent thresholds because residual scores are reduced by control effectiveness.

## 2. Control Effectiveness

The questionnaire has 51 questions weighted 1 to 3 by importance. Each response carries a value:

| Response | Value |
|---|---|
| Yes | 1.0 |
| Partial | 0.5 |
| No | 0.0 |
| N/A | Excluded from numerator and denominator |

```
Control effectiveness = Σ(weight × value) ÷ Σ(weight of answered, applicable questions)
```

Domain scores use the same formula restricted to each domain. Seven questions are flagged as **critical controls** (MFA, encryption at rest and in transit, independent attestation, breach notification, regulatory compliance and DPA, and, for AI vendors, the commitment not to train on customer data). A "No" on any of them is a **critical gap**.

## 3. Residual Risk

```
Residual score = Inherent score × (1 − Control effectiveness × Maximum risk reduction)
```

The maximum risk reduction is set to **70%**. This is an assumption: even a vendor with perfect controls cannot eliminate inherent risk, because the dependency, the data exposure and the potential for control failure remain.

### Recommended decision logic

| Condition (evaluated in order) | Recommended decision |
|---|---|
| Questionnaire not yet scored | Assessment pending |
| Any critical gap | Remediate critical gaps before approval |
| Residual rating Critical | Escalate: executive risk acceptance required |
| Residual rating High | Conditional approval with remediation plan |
| Residual rating Medium | Approve with standard monitoring |
| Residual rating Low | Approve |

## 4. Worked Example (fictional vendor V-002, an AI language platform)

| Factor | Score | Weight | Contribution |
|---|---|---|---|
| Data sensitivity | 5 | 30% | 1.50 |
| Business criticality | 3 | 25% | 0.75 |
| System / network access | 3 | 15% | 0.45 |
| Regulatory exposure | 4 | 10% | 0.40 |
| Substitutability | 2 | 10% | 0.20 |
| AI impact | 5 | 10% | 0.50 |
| **Weighted average** | | | **3.80** |

- **Inherent score** = 3.80 × 20 = **76** → **High**
- **Control effectiveness** = **82%** (questionnaire result)
- **Residual score** = 76 × (1 − 0.815 × 0.70) = **32.6** (control effectiveness shown unrounded) → **Medium**
- **Critical gaps** = 1 (no contractual commitment against training on customer data)
- **Recommended decision:** *Remediate critical gaps before approval*

The example shows why the critical-gap rule matters: the residual rating alone (Medium) would suggest straightforward approval, yet the vendor fails a control that is non-negotiable for an AI service handling sensitive data.

## 5. Vendor Risk Register Scoring (5×5)

Individual risks in the `Risk_Register` are scored separately:

```
Risk score = Likelihood (1–5) × Impact (1–5)
```

| Rating | Score ≥ |
|---|---|
| Low | 1 |
| Medium | 5 |
| High | 10 |
| Critical | 17 |

Each risk is scored twice: **inherent** (before existing and planned controls) and **residual** (after). The `Dashboard` heat map plots open residual risks.

## 6. Limitations

- Scores support judgment; they do not replace it. Reviewers should challenge questionnaire answers that lack evidence.
- Self-reported answers are only as reliable as the evidence behind them. Where evidence is missing, score "Partial" or "No".
- Weights and thresholds should be recalibrated after the first assessment cycle using actual results.
