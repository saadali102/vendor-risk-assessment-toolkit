# Ongoing Monitoring Schedule

Monitoring intensity is driven by the vendor's **inherent** rating, because inherent risk reflects the potential impact if a vendor fails, regardless of how good its controls look today.

## 1. Cadence by Tier

| Activity | Critical | High | Medium | Low | Owner |
|---|---|---|---|---|---|
| Full risk reassessment | 12 months | 18 months | 24 months | 36 months | GRC Analyst |
| Interim check-in (attestation of no material change; open findings review) | 3 months | 6 months | 12 months | At renewal | GRC Analyst |
| Security posture and breach monitoring | Continuous alerts | Monthly | Quarterly | Annually | Security Analyst |
| Certification / attestation validity | Each report cycle | Each report cycle | Annually | At renewal | GRC Analyst |
| Remediation tracking of open findings | Monthly | Monthly | Quarterly | At review | GRC Analyst |
| SLA and service performance review | Quarterly | Quarterly | Semi-annually | Annually | Business Owner |
| Access review of vendor accounts in our environment | Quarterly | Quarterly | Semi-annually | Annually | IT / Business Owner |
| Subprocessor and ownership change review | On notice | On notice | On notice | On notice | Privacy Officer |
| AI model / version change review (AI vendors) | Each major release | Each major release | Quarterly | At renewal | AI Governance Lead |
| Contract renewal review | 180 days before | 180 days before | 120 days before | 90 days before | Procurement |

## 2. Review Calendar

The `Monitoring` sheet calculates, for every vendor in the register:

- the next full reassessment date;
- the next interim check date;
- attestation (SOC 2 / ISO certificate) expiry and status;
- the renewal review date; and
- an overall status: *On track*, *Action due within 90 days*, *Attestation expired*, *Reassessment overdue*, or *Not yet assessed*.

The as-of date is set in `Methodology!B4`. Replace it with `=TODAY()` for live tracking.

## 3. Event-Driven Reassessment Triggers

Reassess regardless of schedule when any of the following occurs:

1. A security incident or data breach at the vendor or one of its subprocessors.
2. A material change in service scope, hosting location, ownership or subprocessors.
3. A lapse, qualification or adverse opinion in a SOC 2 or ISO certification.
4. A significant change to the data shared with the vendor or the vendor's access to systems.
5. A major AI model change, a new AI feature, or a change to the vendor's data-use or retention terms.
6. A new or changed regulation affecting the service (e.g., EU AI Act obligations coming into force).
7. Repeated SLA breaches, financial distress, or negative adverse-media findings.

## 4. Operating Rhythm

| Frequency | Activity | Output |
|---|---|---|
| Monthly | Review Critical/High remediation items and security alerts | Updated Risk Register |
| Quarterly | Review Dashboard; report overdue reviews, expired attestations and open High/Critical risks | Management report |
| Annually | Review the program: thresholds, weights, questionnaire content and cadence | Updated Methodology |
