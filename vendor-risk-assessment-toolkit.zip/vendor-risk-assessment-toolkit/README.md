# Third-Party & Vendor Risk Management Toolkit

A complete, reusable vendor risk assessment package for organizations that rely on **cloud providers and AI software vendors**. It covers the full third-party risk lifecycle: intake, risk tiering, due diligence, scoring, approval, and ongoing monitoring.

> **Sample data is fictional.** The example organization (Meridian Analytics Group) and all vendors are invented. No client or employer data is included.

## What's Included

| Component | Where | Description |
|---|---|---|
| Vendor risk questionnaire | `Questionnaire` sheet | 51 weighted questions across 10 domains, including 8 AI-specific questions and 7 critical controls, mapped to ISO/IEC 27001:2022, ISO/IEC 42001:2023, NIST CSF 2.0 and NIST AI RMF |
| Inherent and residual risk scoring | `Vendor_Register`, `Methodology`, `Assessment_Results` | Six weighted inherent-risk factors, control effectiveness from the questionnaire, and a residual score with rating bands |
| Due diligence checklist | `Due_Diligence` sheet | 34 items across 7 phases, with cloud-specific and AI-specific sections |
| Vendor risk register | `Risk_Register` sheet | 5×5 likelihood × impact scoring, treatment strategy, owners, target dates |
| Security review and approval workflow | `Approval_Workflow` sheet, [docs/03](docs/03-approval-workflow.md) | 10-stage workflow, approval authority matrix, exception rules |
| Ongoing monitoring schedule | `Monitoring` sheet, [docs/04](docs/04-monitoring-schedule.md) | Cadence by tier, calculated review calendar, event-driven triggers |
| Dashboard | `Dashboard` sheet | KPIs, rating distribution chart, residual risk heat map, vendor snapshot |

## Repository Structure

```
vendor-risk-assessment-toolkit/
├── README.md
├── LICENSE
├── templates/
│   └── Vendor_Risk_Management_Workbook.xlsx
└── docs/
    ├── 01-program-overview-and-policy.md
    ├── 02-risk-scoring-methodology.md
    ├── 03-approval-workflow.md
    ├── 04-monitoring-schedule.md
    └── 05-sample-assessment-report.md
```

## Quick Start

1. Open `templates/Vendor_Risk_Management_Workbook.xlsx` in Excel or LibreOffice.
2. Review `Methodology` and adjust weights, thresholds and cadence to match your risk appetite.
3. Add vendors to `Vendor_Register` and score the six inherent-risk factors (1–5).
4. Record each vendor's questionnaire answers in its column on the `Questionnaire` sheet.
5. Review `Assessment_Results` and the recommended decision in `Vendor_Register`.
6. Complete `Due_Diligence`, log risks in `Risk_Register`, obtain approval, and set the review dates.

Blue text on a yellow fill marks input cells. Everything else is a formula.

## How Scoring Works

```
Inherent score   = Σ(factor score × weight) × 20                 (range 20–100)
Control effectiveness = Σ(question weight × response value) ÷ Σ(weight of answered questions)
Residual score   = Inherent score × (1 − control effectiveness × 70%)
```

A "No" on any critical control is a **critical gap** and blocks approval until it is remediated or formally risk-accepted, regardless of the residual score. See [docs/02](docs/02-risk-scoring-methodology.md) for the full method and a worked example.

## Standards Alignment

- ISO/IEC 27001:2022: Annex A.5.19 to A.5.23 (supplier relationships and cloud services) and related controls
- ISO/IEC 42001:2023: Annex A.10 (third-party relationships) and AI system lifecycle controls
- NIST Cybersecurity Framework 2.0: Govern function, Cybersecurity Supply Chain Risk Management (GV.SC)
- NIST AI Risk Management Framework 1.0

Control mappings are indicative. Validate them against the current published standards before using them in an audit.

## Customization Notes

Weights, rating thresholds, the 70% maximum risk reduction, review cycles and the impact scale are illustrative defaults. They are not regulatory requirements. Calibrate them to your organization before use.

## Author

**Saad Ali** | GRC Analyst | ISO/IEC 27001 · ISO/IEC 42001 · AI Governance
[LinkedIn](https://www.linkedin.com/in/saadali112/) · [GitHub](https://github.com/saadali102)

Released under the [MIT License](LICENSE).
